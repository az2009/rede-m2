Configuração da chave: 
 ![Configuração chave](docs/configuracao-chaves-redes.png)
<br/>

Configuração Cartão de Crédito: 
  ![Configuração chave](docs/configuracao-cc-rede.png)
<br/>
  
Configuração Cartão de Débito: 
  ![Configuração chave](docs/configuracao-dc-rede.png)
  
<br/>
URL de Postback: 
  http://SUALOJA.COM.BR/index.php/rede/postback/index/
   - Recebe o parâmetro "tid"(Id da Transação)
   
Telas Gerais